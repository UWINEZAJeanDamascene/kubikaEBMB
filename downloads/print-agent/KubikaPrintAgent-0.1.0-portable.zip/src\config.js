const path = require('path');

const appData = process.env.ProgramData || process.env.LOCALAPPDATA || process.cwd();
const dataDir = process.env.KUBIKA_PRINT_AGENT_DATA_DIR || path.join(appData, 'Kubika', 'PrintAgent');
// The agent source is used directly during local development. Packaged
// production installs set KUBIKA_BACKEND_URL in the WinSW service config.
const defaultBackendUrl = 'http://127.0.0.1:3000';

module.exports = {
  dataDir,
  localPort: Number(process.env.KUBIKA_PRINT_AGENT_PORT || 19100),
  backendUrl: String(process.env.KUBIKA_BACKEND_URL || defaultBackendUrl).replace(/\/+$/, ''),
  pollIntervalMs: Number(process.env.KUBIKA_PRINT_POLL_MS || 10000),
  leaseTimeoutMs: 30000,
};
