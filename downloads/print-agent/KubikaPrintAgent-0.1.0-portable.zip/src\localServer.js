const express = require('express');
const fs = require('fs');
const path = require('path');

function createLocalServer({ ledger, credentialStore, discoverPrinters, transmitDirect, onPair }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10mb' }));

  app.get('/v1/status', (_req, res) => {
    res.json({
      success: true,
      data: {
        paired: Boolean(credentialStore.load()),
        printers: discoverPrinters(),
        service: 'kubika-print-agent',
        version: '0.1.0',
      },
    });
  });

  app.post('/v1/pair', async (req, res) => {
    try {
      const result = await onPair(req.body);
      res.json({
        success: true,
        data: {
          paired: true,
          agentId: result.agentId,
          printers: result.printers || [],
        },
      });
    } catch (error) {
      res.status(400).json({ success: false, code: 'PRINT_PAIRING_FAILED', message: error.message });
    }
  });

  app.post('/v1/jobs', async (req, res) => {
    try {
      const result = await transmitDirect(req.body);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(400).json({ success: false, code: 'LOCAL_PRINT_FAILED', message: error.message });
    }
  });

  app.post('/v1/unpair', (_req, res) => {
    credentialStore.clear();
    res.json({ success: true, data: { paired: false } });
  });

  app.get(['/setup', '/v1/setup'], (_req, res) => {
    res.redirect('/');
  });
  app.get(['/status', '/v1/status'], (_req, res) => {
    const paired = Boolean(credentialStore.load());
    res.json({
      success: true,
      data: {
        paired,
        printers: discoverPrinters(),
        service: 'kubika-print-agent',
        version: '0.1.0',
      },
    });
  });
  app.get(['/logs', '/v1/logs'], (_req, res) => {
    const logDir = process.env.WINSW_SERVICE_LOG_DIR || path.join(process.env.ProgramData || process.cwd(), 'Kubika', 'PrintAgent', 'logs');
    const files = fs.existsSync(logDir)
      ? fs.readdirSync(logDir).filter((name) => name.endsWith('.log')).slice(-5)
      : [];
    const lines = files.flatMap((name) => {
      try { return fs.readFileSync(path.join(logDir, name), 'utf8').split(/\r?\n/).slice(-100); } catch { return []; }
    });
    res.json({ success: true, data: { lines } });
  });

  app.get('/', (_req, res) => {
    res.type('html').send(`<!doctype html><html><body style="font-family:sans-serif;max-width:720px;margin:40px auto">
      <h1>Kubika Print Agent</h1>
      <p>Local setup and diagnostics. This page is available only on this computer.</p>
      <h2>Pair agent</h2>
      <form id="pair"><label>Pairing code</label><br><input name="pairingCode" placeholder="KUBIKA-XXXXXXXX" required><br><br>
      <label>Device name</label><br><input name="name" value="Shop Print Agent"><br><br>
      <button>Pair</button></form><pre id="result"></pre>
      <script>
        pair.onsubmit=async e=>{
          e.preventDefault();
          const button=e.submitter;
          button.disabled=true;
          const f=new FormData(pair);
          const body=Object.fromEntries(f);
          body.deviceId=crypto.randomUUID();
          body.platform=navigator.platform.includes('Win')?'windows':'other';
          result.textContent='Pairing...';
          try{
            const r=await fetch('/v1/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
            const response=await r.json();
            if(r.ok&&response.success&&response.data?.paired){
              result.textContent='Success: Print Agent paired successfully.';
            }else{
              result.textContent='Pairing failed: '+(response.message||'Please check the pairing code and try again.');
            }
          }catch(error){
            result.textContent='Pairing failed: unable to connect to the local Print Agent.';
          }finally{
            button.disabled=false;
          }
        };
      </script>
    </body></html>`);
  });

  return app;
}

module.exports = { createLocalServer };
